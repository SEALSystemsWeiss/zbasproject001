sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend("seal.zproject001.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
